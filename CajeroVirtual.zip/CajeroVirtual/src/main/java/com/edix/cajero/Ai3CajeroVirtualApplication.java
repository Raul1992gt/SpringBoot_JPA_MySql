package com.edix.cajero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ai3CajeroVirtualApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ai3CajeroVirtualApplication.class, args);
	}

}
