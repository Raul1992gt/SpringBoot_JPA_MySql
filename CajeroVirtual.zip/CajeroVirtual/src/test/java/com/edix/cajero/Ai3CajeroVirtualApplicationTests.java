package com.edix.cajero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ai3CajeroVirtualApplicationTests {

	@Test
	void contextLoads() {
	}

}
